# contenido del archivo transformacion.py


def convertir_a_mayusculas(texto):
    return texto.upper()


def convertir_a_minusculas(texto):
    return texto.lower()